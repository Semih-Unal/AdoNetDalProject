﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdoNet_DAL_Detayli_Proje.Categories
{
    public partial class frmListele : Form
    {
        public frmListele()
        {
            InitializeComponent();
        }

        private void frmListele_Load(object sender, EventArgs e)
        {
            Fill();
        }

        DAL.CategoryDal catDal = new DAL.CategoryDal();
        private void Fill()
        {
            lstwCategories.Items.Clear();

            List<Entity.Category> kategoriler = catDal.List();

            foreach (Entity.Category c in kategoriler)
            {
                ListViewItem li = new ListViewItem();

                li.Tag = c;
                li.Text = c.CategoryName.ToString();
                li.SubItems.Add(c.Description.ToString());

                lstwCategories.Items.Add(li);
            }

            toolStripStatusLabelVeriler.Text = lstwCategories.Items.Count.ToString() + " adet kategori listelenmiştir.";
        }
    }
}
