﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdoNet_DAL_Detayli_Proje.Categories
{
    public partial class frmSil : Form
    {
        public frmSil()
        {
            InitializeComponent();
        }
        DAL.CategoryDal catDal = new DAL.CategoryDal();
        private void frmSil_Load(object sender, EventArgs e)
        {
            CategoryFill();
        }
        private void CategoryFill()
        {
            List<Entity.Category> kategoriler = catDal.List();
            dGwCategories.Rows.Clear();

            dGwCategories.DataSource = kategoriler;

            this.Text = "- Kategori Silme - " + dGwCategories.Rows.Count.ToString() + " Adet Kategori Listelenmiştir.";
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Silmek İstediğinize Emin Misiniz?", "Silme İşlemi", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == DialogResult.Yes)
            {
                int result = catDal.Delete(dGwCategories.Rows[0].Cells[2].Value);

                if (result != 0)
                {
                    MessageBox.Show("Silme İşleminiz Başarılı Şekilde Gerçekleşmiştir.");
                    this.Close();
                    Categories.frmListele yavruList = new Categories.frmListele();
                    //yavruList.MdiParent = this;
                    yavruList.Show();
                }
            }
        }
    }
}
