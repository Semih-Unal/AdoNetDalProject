﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdoNet_DAL_Detayli_Proje.Categories
{
    public partial class frmGuncelle : Form
    {
        public frmGuncelle()
        {
            InitializeComponent();
        }
        DAL.CategoryDal catDal = new DAL.CategoryDal();
        private void frmGuncelle_Load(object sender, EventArgs e)
        {
            CategoryFill();
        }
        
        private void CategoryFill()
        {
            List<Entity.Category> kategoriler = catDal.List();
            lstCategories.Items.Clear();
            foreach (Entity.Category c in kategoriler)
            {
                lstCategories.Items.Add(c);
            }

            this.Text = "- Kategori Güncelleme - " + lstCategories.Items.Count.ToString() + " Adet Kategori Listelenmiştir.";
        }

        private void lstCategories_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstCategories.SelectedItem == null)
            {
                MessageBox.Show("Lütfen Güncellemek İstediğiniz Kategoriyi Seçiniz!");
                return;
            }

            Entity.Category secilenKategori = lstCategories.SelectedItem as Entity.Category;

            txtUpdateCategoryName.Text = secilenKategori.CategoryName.ToString();
            txtUpdateDescription.Text = secilenKategori.Description.ToString();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            Entity.Category cats = new Entity.Category();
            Entity.Category secilenKategori = lstCategories.SelectedItem as Entity.Category;

            cats.CategoryName = txtUpdateCategoryName.Text;
            cats.Description = txtUpdateDescription.Text;
            //------------------------------------
            cats.id = Convert.ToInt32(secilenKategori.id);

            int result = catDal.Update(cats);

            if (result != 0)
            {
                MessageBox.Show("Güncelleme İşleminiz Başarılı Şekilde Gerçekleşmiştir.");
                this.Close();
                Categories.frmListele yavruList = new Categories.frmListele();
                //yavruList.MdiParent = this;
                yavruList.Show();
            }
        }
    }
}
