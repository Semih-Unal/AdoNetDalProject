﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdoNet_DAL_Detayli_Proje.Categories
{
    public partial class frmEkle : Form
    {
        public frmEkle()
        {
            InitializeComponent();
        }

        DAL.CategoryDal catDal = new DAL.CategoryDal();
        private void btnSave_Click(object sender, EventArgs e)
        {
            Entity.Category cats = new Entity.Category();

            cats.CategoryName = txtCategoryName.Text;
            cats.Description = txtDescription.Text;

            int result = catDal.Save(cats);
            if (result != 0)
            {
                MessageBox.Show("Kaydetme İşleminiz Başarılı Şekilde Gerçekleşmiştir.");
                this.Close();
                Categories.frmListele yavruList = new Categories.frmListele();
                //yavruList.MdiParent = this;
                yavruList.Show();
            }
        }

        private void frmEkle_Load(object sender, EventArgs e)
        {

        }
    }
}
