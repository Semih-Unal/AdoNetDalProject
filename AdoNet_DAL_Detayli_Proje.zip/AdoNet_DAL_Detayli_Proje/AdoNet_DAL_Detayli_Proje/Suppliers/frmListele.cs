﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdoNet_DAL_Detayli_Proje.Suppliers
{
    public partial class frmListele : Form
    {
        public frmListele()
        {
            InitializeComponent();
        }
        DAL.SupplierDal supDal = new DAL.SupplierDal();
        private void frmListele_Load(object sender, EventArgs e)
        {
            SupplierFill();
        }

        private void SupplierFill()
        {
            List<Entity.Supplier> tedarikciler = supDal.List();
            lstwSuppliers.Items.Clear();
            foreach (Entity.Supplier s in tedarikciler)
            {
                ListViewItem li = new ListViewItem();
                li.Tag = s;
                li.Text = s.CompanyName;
                li.SubItems.Add(s.ContactName.ToString());
                li.SubItems.Add(s.ContactTitle.ToString());
                li.SubItems.Add(s.Address.ToString());
                li.SubItems.Add(s.City.ToString());
                li.SubItems.Add(s.Region.ToString());
                li.SubItems.Add(s.PostalCode.ToString());
                li.SubItems.Add(s.Country.ToString());
                li.SubItems.Add(s.Phone.ToString());
                li.SubItems.Add(s.Fax.ToString());

                lstwSuppliers.Items.Add(li);
            }
            toolStripStatusLabelSuppliers.Text = lstwSuppliers.Items.Count.ToString() + " adet tedarikçi listelenmiştir...";
        }
    }
}
