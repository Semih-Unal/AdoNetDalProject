﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdoNet_DAL_Detayli_Proje.Suppliers
{
    public partial class frmSil : Form
    {
        public frmSil()
        {
            InitializeComponent();
        }
        DAL.SupplierDal supDal = new DAL.SupplierDal();
        private void frmSil_Load(object sender, EventArgs e)
        {
            SupplierFill();
        }
        private void SupplierFill()
        {
            dGwSuppliers.Rows.Clear();
            List<Entity.Supplier> tedarikciler = supDal.List();

            dGwSuppliers.DataSource = tedarikciler;

            this.Text = "- Tedarikçi Silme - " + dGwSuppliers.Rows.Count.ToString() + " Adet Tedarikçi Listelenmiştir.";
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Silmek İstediğinize Emin Misiniz?", "Silme İşlemi", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == DialogResult.Yes)
            {
                int result = supDal.Delete(dGwSuppliers.Rows[0].Cells[10].Value);

                if (result != 0)
                {
                    MessageBox.Show("Silme İşleminiz Başarılı Şekilde Gerçekleşmiştir.");
                    this.Close();
                    Suppliers.frmListele yavruList = new Suppliers.frmListele();
                    //yavruList.MdiParent = this;
                    yavruList.Show();
                }
            }
        }
    }
}
