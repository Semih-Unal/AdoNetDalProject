﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdoNet_DAL_Detayli_Proje.Suppliers
{
    public partial class frmEkle : Form
    {
        public frmEkle()
        {
            InitializeComponent();
        }
        DAL.SupplierDal supDal = new DAL.SupplierDal();
        private void btnSave_Click(object sender, EventArgs e)
        {
            Entity.Supplier sups = new Entity.Supplier();

            sups.CompanyName = txtCompanyName.Text.ToString();
            sups.ContactName = txtContactName.Text.ToString();
            sups.ContactTitle = txtContactTitle.Text.ToString();
            sups.City = txtCity.Text.ToString();
            sups.Region = txtRegion.Text.ToString();
            sups.PostalCode = txtPostalCode.Text.ToString();
            sups.Country = txtCountry.Text.ToString();
            sups.Phone = mtxtPhone.Text.ToString();
            sups.Fax = mtxtFax.Text.ToString();
            sups.Address = txtAddress.Text.ToString();

            int result = supDal.Save(sups);

            if (result != 0)
            {
                MessageBox.Show("Kaydetme İşleminiz Başarılı Şekilde Gerçekleşmiştir.");
                this.Close();
                Suppliers.frmListele yavruList = new Suppliers.frmListele();
                //yavruList.MdiParent = this;
                yavruList.Show();
            }
        }

        private void frmEkle_Load(object sender, EventArgs e)
        {

        }
    }
}
