﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdoNet_DAL_Detayli_Proje.Suppliers
{
    public partial class frmGuncelle : Form
    {
        public frmGuncelle()
        {
            InitializeComponent();
        }
        DAL.SupplierDal supDal = new DAL.SupplierDal();
        private void frmGuncelle_Load(object sender, EventArgs e)
        {
            SupplierFill();
        }

        private void SupplierFill()
        {
            lstSuppliers.Items.Clear();
            List<Entity.Supplier> tedarikciler = supDal.List();

            foreach (Entity.Supplier t in tedarikciler)
            {
                lstSuppliers.Items.Add(t);
            }

            this.Text = "- Tedarikçi Güncelleme - " + lstSuppliers.Items.Count.ToString() + " Adet Tedarikçi Listelenmiştir.";
        }

        private void lstSuppliers_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstSuppliers.SelectedItem == null)
            {
                MessageBox.Show("Lütfen Güncellemek İstediğiniz Tedarikçiyi Seçiniz!");
                return;
            }

            Entity.Supplier secilentedarikci = lstSuppliers.SelectedItem as Entity.Supplier;

            txtUpdateCompanyName.Text = secilentedarikci.CompanyName.ToString();
            txtUpdateContactName.Text = secilentedarikci.ContactName.ToString();
            txtUpdateContactTitle.Text = secilentedarikci.ContactTitle.ToString();
            txtUpdateCity.Text = secilentedarikci.City.ToString();
            txtUpdateRegion.Text = secilentedarikci.Region.ToString();
            txtUpdatePostalCode.Text = secilentedarikci.PostalCode.ToString();
            txtUpdateCountry.Text = secilentedarikci.Country.ToString();
            mtxtUpdatePhone.Text = secilentedarikci.Phone.ToString();
            mtxtUpdateFax.Text = secilentedarikci.Fax.ToString();
            txtUpdateAddress.Text = secilentedarikci.Address.ToString();

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            Entity.Supplier sups = new Entity.Supplier();

            Entity.Supplier secilentedarikci = lstSuppliers.SelectedItem as Entity.Supplier;

            sups.CompanyName = txtUpdateCompanyName.Text ;
            sups.ContactName = txtUpdateContactName.Text ;
            sups.ContactTitle = txtUpdateContactTitle.Text ;
            sups.City = txtUpdateCity.Text;
            sups.Region = txtUpdateRegion.Text ;
            sups.PostalCode = txtUpdatePostalCode.Text;
            sups.Country = txtUpdateCountry.Text ;
            sups.Phone = mtxtUpdatePhone.Text ;
            sups.Fax = mtxtUpdateFax.Text ;
            sups.Address = txtUpdateAddress.Text ;

            sups.id = Convert.ToInt32(secilentedarikci.id);

            int result = supDal.Update(sups);
            if (result != 0)
            {
                MessageBox.Show("Güncelleme İşleminiz Başarılı Şekilde Gerçekleşmiştir.");
                this.Close();
                Suppliers.frmListele yavruList = new Suppliers.frmListele();
                //yavruList.MdiParent = this;
                yavruList.Show();
            }
        }
    }
}
