﻿namespace AdoNet_DAL_Detayli_Proje.Suppliers
{
    partial class frmGuncelle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstSuppliers = new System.Windows.Forms.ListBox();
            this.mtxtUpdateFax = new System.Windows.Forms.MaskedTextBox();
            this.mtxtUpdatePhone = new System.Windows.Forms.MaskedTextBox();
            this.txtUpdateAddress = new System.Windows.Forms.TextBox();
            this.txtUpdateRegion = new System.Windows.Forms.TextBox();
            this.txtUpdateContactName = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtUpdateContactTitle = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtUpdatePostalCode = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtUpdateCity = new System.Windows.Forms.TextBox();
            this.lblCity = new System.Windows.Forms.Label();
            this.txtUpdateCompanyName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.txtUpdateCountry = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lstSuppliers
            // 
            this.lstSuppliers.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lstSuppliers.ForeColor = System.Drawing.Color.Magenta;
            this.lstSuppliers.FormattingEnabled = true;
            this.lstSuppliers.ItemHeight = 20;
            this.lstSuppliers.Location = new System.Drawing.Point(12, 12);
            this.lstSuppliers.Name = "lstSuppliers";
            this.lstSuppliers.Size = new System.Drawing.Size(476, 124);
            this.lstSuppliers.TabIndex = 1;
            this.lstSuppliers.SelectedIndexChanged += new System.EventHandler(this.lstSuppliers_SelectedIndexChanged);
            // 
            // mtxtUpdateFax
            // 
            this.mtxtUpdateFax.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.mtxtUpdateFax.Location = new System.Drawing.Point(201, 534);
            this.mtxtUpdateFax.Mask = "(999) 000-00-00";
            this.mtxtUpdateFax.Name = "mtxtUpdateFax";
            this.mtxtUpdateFax.Size = new System.Drawing.Size(287, 30);
            this.mtxtUpdateFax.TabIndex = 20;
            // 
            // mtxtUpdatePhone
            // 
            this.mtxtUpdatePhone.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.mtxtUpdatePhone.Location = new System.Drawing.Point(201, 480);
            this.mtxtUpdatePhone.Mask = "(999) 000-00-00";
            this.mtxtUpdatePhone.Name = "mtxtUpdatePhone";
            this.mtxtUpdatePhone.Size = new System.Drawing.Size(287, 30);
            this.mtxtUpdatePhone.TabIndex = 19;
            // 
            // txtUpdateAddress
            // 
            this.txtUpdateAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtUpdateAddress.Location = new System.Drawing.Point(201, 584);
            this.txtUpdateAddress.MaxLength = 60;
            this.txtUpdateAddress.Multiline = true;
            this.txtUpdateAddress.Name = "txtUpdateAddress";
            this.txtUpdateAddress.Size = new System.Drawing.Size(287, 93);
            this.txtUpdateAddress.TabIndex = 17;
            // 
            // txtUpdateRegion
            // 
            this.txtUpdateRegion.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtUpdateRegion.Location = new System.Drawing.Point(200, 336);
            this.txtUpdateRegion.MaxLength = 15;
            this.txtUpdateRegion.Name = "txtUpdateRegion";
            this.txtUpdateRegion.Size = new System.Drawing.Size(287, 30);
            this.txtUpdateRegion.TabIndex = 15;
            // 
            // txtUpdateContactName
            // 
            this.txtUpdateContactName.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtUpdateContactName.Location = new System.Drawing.Point(200, 194);
            this.txtUpdateContactName.MaxLength = 30;
            this.txtUpdateContactName.Name = "txtUpdateContactName";
            this.txtUpdateContactName.Size = new System.Drawing.Size(287, 30);
            this.txtUpdateContactName.TabIndex = 13;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.Location = new System.Drawing.Point(13, 534);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(61, 25);
            this.label8.TabIndex = 10;
            this.label8.Text = "Fax : ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.Location = new System.Drawing.Point(13, 587);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(101, 25);
            this.label4.TabIndex = 11;
            this.label4.Text = "Address : ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.Location = new System.Drawing.Point(13, 480);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(85, 25);
            this.label7.TabIndex = 8;
            this.label7.Text = "Phone : ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.Location = new System.Drawing.Point(12, 339);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(89, 25);
            this.label6.TabIndex = 3;
            this.label6.Text = "Region : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(12, 197);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(148, 25);
            this.label2.TabIndex = 7;
            this.label2.Text = "ContactName : ";
            // 
            // txtUpdateContactTitle
            // 
            this.txtUpdateContactTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtUpdateContactTitle.Location = new System.Drawing.Point(200, 241);
            this.txtUpdateContactTitle.MaxLength = 30;
            this.txtUpdateContactTitle.Name = "txtUpdateContactTitle";
            this.txtUpdateContactTitle.Size = new System.Drawing.Size(287, 30);
            this.txtUpdateContactTitle.TabIndex = 14;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(12, 244);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(133, 25);
            this.label3.TabIndex = 6;
            this.label3.Text = "ContactTitle : ";
            // 
            // txtUpdatePostalCode
            // 
            this.txtUpdatePostalCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtUpdatePostalCode.Location = new System.Drawing.Point(200, 384);
            this.txtUpdatePostalCode.MaxLength = 10;
            this.txtUpdatePostalCode.Name = "txtUpdatePostalCode";
            this.txtUpdatePostalCode.Size = new System.Drawing.Size(287, 30);
            this.txtUpdatePostalCode.TabIndex = 16;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.Location = new System.Drawing.Point(12, 387);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(130, 25);
            this.label5.TabIndex = 5;
            this.label5.Text = "PostalCode : ";
            // 
            // txtUpdateCity
            // 
            this.txtUpdateCity.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtUpdateCity.Location = new System.Drawing.Point(200, 288);
            this.txtUpdateCity.MaxLength = 15;
            this.txtUpdateCity.Name = "txtUpdateCity";
            this.txtUpdateCity.Size = new System.Drawing.Size(287, 30);
            this.txtUpdateCity.TabIndex = 18;
            // 
            // lblCity
            // 
            this.lblCity.AutoSize = true;
            this.lblCity.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblCity.Location = new System.Drawing.Point(12, 291);
            this.lblCity.Name = "lblCity";
            this.lblCity.Size = new System.Drawing.Size(62, 25);
            this.lblCity.TabIndex = 4;
            this.lblCity.Text = "City : ";
            // 
            // txtUpdateCompanyName
            // 
            this.txtUpdateCompanyName.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtUpdateCompanyName.Location = new System.Drawing.Point(200, 146);
            this.txtUpdateCompanyName.MaxLength = 40;
            this.txtUpdateCompanyName.Name = "txtUpdateCompanyName";
            this.txtUpdateCompanyName.Size = new System.Drawing.Size(287, 30);
            this.txtUpdateCompanyName.TabIndex = 12;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(12, 149);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(165, 25);
            this.label1.TabIndex = 9;
            this.label1.Text = "CompanyName : ";
            // 
            // btnUpdate
            // 
            this.btnUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnUpdate.Image = global::AdoNet_DAL_Detayli_Proje.Properties.Resources.update_icon;
            this.btnUpdate.Location = new System.Drawing.Point(314, 687);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(174, 51);
            this.btnUpdate.TabIndex = 21;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnUpdate.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // txtUpdateCountry
            // 
            this.txtUpdateCountry.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtUpdateCountry.Location = new System.Drawing.Point(201, 429);
            this.txtUpdateCountry.MaxLength = 15;
            this.txtUpdateCountry.Name = "txtUpdateCountry";
            this.txtUpdateCountry.Size = new System.Drawing.Size(287, 30);
            this.txtUpdateCountry.TabIndex = 23;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label9.Location = new System.Drawing.Point(13, 432);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(97, 25);
            this.label9.TabIndex = 22;
            this.label9.Text = "Country : ";
            // 
            // frmGuncelle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(502, 750);
            this.Controls.Add(this.txtUpdateCountry);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.mtxtUpdateFax);
            this.Controls.Add(this.mtxtUpdatePhone);
            this.Controls.Add(this.txtUpdateAddress);
            this.Controls.Add(this.txtUpdateRegion);
            this.Controls.Add(this.txtUpdateContactName);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtUpdateContactTitle);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtUpdatePostalCode);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtUpdateCity);
            this.Controls.Add(this.lblCity);
            this.Controls.Add(this.txtUpdateCompanyName);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lstSuppliers);
            this.Name = "frmGuncelle";
            this.Text = "- Tedarikçi Güncelleme -";
            this.Load += new System.EventHandler(this.frmGuncelle_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lstSuppliers;
        private System.Windows.Forms.MaskedTextBox mtxtUpdateFax;
        private System.Windows.Forms.MaskedTextBox mtxtUpdatePhone;
        private System.Windows.Forms.TextBox txtUpdateAddress;
        private System.Windows.Forms.TextBox txtUpdateRegion;
        private System.Windows.Forms.TextBox txtUpdateContactName;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtUpdateContactTitle;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtUpdatePostalCode;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtUpdateCity;
        private System.Windows.Forms.Label lblCity;
        private System.Windows.Forms.TextBox txtUpdateCompanyName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.TextBox txtUpdateCountry;
        private System.Windows.Forms.Label label9;
    }
}