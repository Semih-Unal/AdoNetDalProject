﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace AdoNet_DAL_Detayli_Proje.Products
{
    public partial class frmEkle : Form
    {
        public frmEkle()
        {
            InitializeComponent();
        }
        SqlConnection cnn = new SqlConnection(Properties.Settings.Default.SqlConString);
        private void frmEkle_Load(object sender, EventArgs e)
        {
            // Category için
            CategoryFill();

            // Supplier için
            SupplierFill();
        }

        private void SupplierFill()
        {
            SqlCommand cmd = new SqlCommand("Select * From Suppliers", cnn);
            cbSupplier.Items.Clear();
            try
            {
                if (cnn.State == ConnectionState.Closed)
                    cnn.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        // DAL klasörüne CategoryDal ve SupplierDal ekledik
                        Entity.Supplier sup = new Entity.Supplier();
                        sup.id = Convert.ToInt32(reader["SupplierID"].ToString()); // Kalıtımdan geldi...
                        //-------------------------------
                        sup.CompanyName = reader["CompanyName"].ToString();

                        cbSupplier.Items.Add(sup);
                        cbSupplier.SelectedIndex = 0;
                    }
                }
            }
            catch (SqlException ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            catch (Exception ey)
            {
                System.Windows.Forms.MessageBox.Show(ey.Message);
            }
            finally
            {
                cnn.Close();
            }
        }

        private void CategoryFill()
        {
            SqlCommand cmd = new SqlCommand("Select * From Categories", cnn);
            cbCategory.Items.Clear();
            try
            {
                if (cnn.State == ConnectionState.Closed)
                    cnn.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        // DAL klasörüne CategoryDal ve SupplierDal ekledik
                        Entity.Category cat = new Entity.Category();
                        cat.id = Convert.ToInt32(reader["CategoryID"].ToString()); // Kalıtımdan geldi...
                        //-------------------------------
                        cat.CategoryName = reader["CategoryName"].ToString();
                        cat.Description = reader["Description"].ToString();

                        cbCategory.Items.Add(cat);
                        cbCategory.SelectedIndex = 0;
                    }
                }
            }
            catch (SqlException ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            catch (Exception ey)
            {
                System.Windows.Forms.MessageBox.Show(ey.Message);
            }
            finally
            {
                cnn.Close();
            }
        }
        // şimdi ProductDal içindeki save(); duldurum geliyorum... ordayım...
        DAL.ProductDal prodDal = new DAL.ProductDal();
        private void btnSave_Click(object sender, EventArgs e)
        {
            // 16. ProductDal - Save metodu içinden geldik

            Entity.Products urun = new Entity.Products();

            urun.ProductName = txtProductName.Text;
            urun.UnitPrice = Convert.ToDecimal(txtUnitPrice.Text);
            urun.UnitsInStock = Convert.ToInt32(nUdUnitsInStock.Value);

            Entity.Category secilenKategori = cbCategory.SelectedItem as Entity.Category;
            Entity.Supplier secilenFirma = cbSupplier.SelectedItem as Entity.Supplier;

            urun.CategoryID = Convert.ToInt32(secilenKategori.id);
            urun.SupplierID = Convert.ToInt32(secilenFirma.id);

            int sonuc = prodDal.Save(urun);
            if (sonuc != 0)
            {
                MessageBox.Show("Kaydetme İşleminiz Başarılı Şekilde Gerçekleşmiştir.");
                this.Close();
                Products.frmListele yavruList = new Products.frmListele();
                //yavruList.MdiParent = this;
                yavruList.Show();
            }
            //txtProductName.ResetText();
            //txtUnitPrice.ResetText();
            //nUdUnitsInStock.Value = 1;
            //cbCategory.SelectedIndex = 0;
            //cbSupplier.SelectedIndex = 0;
        }
    }
}
