﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdoNet_DAL_Detayli_Proje.Products
{
    public partial class frmListele : Form
    {
        public frmListele()
        {
            InitializeComponent();
        }
        // 10. Anaformdan geldim
        DAL.ProductDal prodDal = new DAL.ProductDal();
        private void frmListele_Load(object sender, EventArgs e)
        {
            Fill(); // metodu altta...
        }

        private void Fill()
        {
            lstwProducts.Items.Clear(); 
            List<Entity.Products> urunler = prodDal.List(); // buradaki List(); products classının içindeki list metodu
            //Tüm Hazır bekleyen yapımı buradaki urunler listeme atmış oldum...

            foreach (Entity.Products p in urunler)
            {
                ListViewItem li = new ListViewItem();

                li.Tag = p;
                li.Text = p.ProductName;

                li.SubItems.Add(String.Format("{0:C2}",p.UnitPrice));
                li.SubItems.Add(p.UnitsInStock.ToString());
                li.SubItems.Add(p.UnitsOnOrder.ToString());
                li.SubItems.Add(p.Discontinued.ToString());
                li.SubItems.Add(p.CategoryID.ToString());
                li.SubItems.Add(p.SupplierID.ToString());

                lstwProducts.Items.Add(li);
            }

            toolStripStatusLabelVeriler.Text = lstwProducts.Items.Count.ToString() + " adet ürün listelenmiştir.";
        }
    }
}
