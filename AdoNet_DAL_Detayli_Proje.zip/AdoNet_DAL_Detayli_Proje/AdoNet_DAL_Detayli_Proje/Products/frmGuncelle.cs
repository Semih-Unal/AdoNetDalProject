﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace AdoNet_DAL_Detayli_Proje.Products
{
    public partial class frmGuncelle : Form
    {
        public frmGuncelle()
        {
            InitializeComponent();
        }

        SqlConnection cnn = new SqlConnection(Properties.Settings.Default.SqlConString);

        private void frmGuncelle_Load(object sender, EventArgs e)
        {
            // Category için
            CategoryFill();

            // Supplier için
            SupplierFill();

            ProductFill();
        }
        DAL.ProductDal prodDAL = new DAL.ProductDal();
        private void ProductFill()
        {
            lstProducts.Items.Clear();
            List<Entity.Products> urunler = prodDAL.List();

            foreach (Entity.Products item in urunler)
            {
                lstProducts.Items.Add(item);
            }
            this.Text = "- Veri Güncelleme - " + lstProducts.Items.Count.ToString() + " Adet Ürün Listelenmiştir.";
        }

        private void SupplierFill()
        {
            SqlCommand cmd = new SqlCommand("Select * From Suppliers", cnn);
            cbUpdateSupplier.Items.Clear();
            try
            {
                if (cnn.State == ConnectionState.Closed)
                    cnn.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        // DAL klasörüne CategoryDal ve SupplierDal ekledik
                        Entity.Supplier sup = new Entity.Supplier();
                        sup.id = Convert.ToInt32(reader["SupplierID"].ToString()); // Kalıtımdan geldi...
                        //-------------------------------
                        sup.CompanyName = reader["CompanyName"].ToString();

                        cbUpdateSupplier.Items.Add(sup);
                        cbUpdateSupplier.SelectedIndex = 0;
                    }
                }
            }
            catch (SqlException ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            catch (Exception ey)
            {
                System.Windows.Forms.MessageBox.Show(ey.Message);
            }
            finally
            {
                cnn.Close();
            }
        }

        private void CategoryFill()
        {
            SqlCommand cmd = new SqlCommand("Select * From Categories", cnn);
            cbUpdateCategory.Items.Clear();
            try
            {
                if (cnn.State == ConnectionState.Closed)
                    cnn.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        // DAL klasörüne CategoryDal ve SupplierDal ekledik
                        Entity.Category cat = new Entity.Category();
                        cat.id = Convert.ToInt32(reader["CategoryID"].ToString()); // Kalıtımdan geldi...
                        //-------------------------------
                        cat.CategoryName = reader["CategoryName"].ToString();
                        cat.Description = reader["Description"].ToString();

                        cbUpdateCategory.Items.Add(cat);
                        cbUpdateCategory.SelectedIndex = 0;
                    }
                }
            }
            catch (SqlException ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            catch (Exception ey)
            {
                System.Windows.Forms.MessageBox.Show(ey.Message);
            }
            finally
            {
                cnn.Close();
            }
        }

        private void lstProducts_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstProducts.SelectedItem == null)
            {
                MessageBox.Show("Lütfen güncellemek istediğiniz ürünü seçiniz.");
                return;
            }

            Entity.Products secilenUrun = lstProducts.SelectedItem as Entity.Products;

            txtUpdateProductName.Text = secilenUrun.ProductName.ToString();
            txtUpdateUnitPrice.Text = secilenUrun.UnitPrice.ToString();
            nUdUpdateUnitsInStock.Value = secilenUrun.UnitsInStock;
            //------------------------------
            cbUpdateCategory.SelectedIndex = secilenUrun.CategoryID - 1;
            cbUpdateSupplier.SelectedIndex = secilenUrun.SupplierID - 1;

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            Entity.Products prod = new Entity.Products();

            Entity.Products secilenUrun = lstProducts.SelectedItem as Entity.Products;
            prod.id = secilenUrun.id;

            prod.ProductName = txtUpdateProductName.Text;
            prod.UnitPrice = Convert.ToDecimal(txtUpdateUnitPrice.Text);
            prod.UnitsInStock = Convert.ToInt32(nUdUpdateUnitsInStock.Value);
            prod.CategoryID = Convert.ToInt32(cbUpdateCategory.SelectedIndex ) + 1;
            prod.SupplierID = Convert.ToInt32(cbUpdateSupplier.SelectedIndex) + 1;

            
            int sonuc = prodDAL.Update(prod);
            if (sonuc != 0)
            {
                MessageBox.Show("Güncelleme İşleminiz Başarılı Şekilde Gerçekleşmiştir.");
                this.Close();
                Products.frmListele yavruList = new Products.frmListele();
                //yavruList.MdiParent = this;
                yavruList.Show();
            }
        }
    }
}
