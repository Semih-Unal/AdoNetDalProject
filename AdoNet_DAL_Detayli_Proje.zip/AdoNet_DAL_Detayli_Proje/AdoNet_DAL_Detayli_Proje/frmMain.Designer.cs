﻿namespace AdoNet_DAL_Detayli_Proje
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStripVeriler = new System.Windows.Forms.MenuStrip();
            this.ürünlerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tümÜrünleriListeleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.yeniToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ürünEkleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ürünGüncelleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ürünSilToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.çıkışToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hizalamalarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.basamaklaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.yatayHizalaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dikeyHizalaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kategoriToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tümKategorilerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.yeniToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.kategoriEkleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kategoriGüncelleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kategoriSilToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.çıkışToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.tedarikçilerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.yeniToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.tedarikçiEkleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tedarikçiGüncelleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tedarikçiSilToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.çıkışToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.siparişlerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tümSiparişToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.yeniToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.siparişEkleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.siparişGüncelleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.siparişSilToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.çıkışToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabelDurum = new System.Windows.Forms.ToolStripStatusLabel();
            this.menuStripVeriler.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStripVeriler
            // 
            this.menuStripVeriler.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.menuStripVeriler.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.menuStripVeriler.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ürünlerToolStripMenuItem,
            this.hizalamalarToolStripMenuItem,
            this.kategoriToolStripMenuItem,
            this.tedarikçilerToolStripMenuItem,
            this.siparişlerToolStripMenuItem});
            this.menuStripVeriler.Location = new System.Drawing.Point(0, 0);
            this.menuStripVeriler.Name = "menuStripVeriler";
            this.menuStripVeriler.Size = new System.Drawing.Size(838, 29);
            this.menuStripVeriler.TabIndex = 0;
            this.menuStripVeriler.Text = "menuStrip1";
            // 
            // ürünlerToolStripMenuItem
            // 
            this.ürünlerToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tümÜrünleriListeleToolStripMenuItem,
            this.toolStripSeparator1,
            this.yeniToolStripMenuItem,
            this.ürünGüncelleToolStripMenuItem,
            this.ürünSilToolStripMenuItem,
            this.toolStripSeparator2,
            this.çıkışToolStripMenuItem});
            this.ürünlerToolStripMenuItem.Name = "ürünlerToolStripMenuItem";
            this.ürünlerToolStripMenuItem.Size = new System.Drawing.Size(75, 25);
            this.ürünlerToolStripMenuItem.Text = "Ürünler";
            // 
            // tümÜrünleriListeleToolStripMenuItem
            // 
            this.tümÜrünleriListeleToolStripMenuItem.Image = global::AdoNet_DAL_Detayli_Proje.Properties.Resources.list;
            this.tümÜrünleriListeleToolStripMenuItem.Name = "tümÜrünleriListeleToolStripMenuItem";
            this.tümÜrünleriListeleToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.L)));
            this.tümÜrünleriListeleToolStripMenuItem.Size = new System.Drawing.Size(274, 26);
            this.tümÜrünleriListeleToolStripMenuItem.Text = "Tüm Ürünleri Listele";
            this.tümÜrünleriListeleToolStripMenuItem.Click += new System.EventHandler(this.tümÜrünleriListeleToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(271, 6);
            // 
            // yeniToolStripMenuItem
            // 
            this.yeniToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ürünEkleToolStripMenuItem});
            this.yeniToolStripMenuItem.Image = global::AdoNet_DAL_Detayli_Proje.Properties.Resources._new;
            this.yeniToolStripMenuItem.Name = "yeniToolStripMenuItem";
            this.yeniToolStripMenuItem.Size = new System.Drawing.Size(274, 26);
            this.yeniToolStripMenuItem.Text = "Yeni >>>";
            // 
            // ürünEkleToolStripMenuItem
            // 
            this.ürünEkleToolStripMenuItem.Name = "ürünEkleToolStripMenuItem";
            this.ürünEkleToolStripMenuItem.Size = new System.Drawing.Size(147, 26);
            this.ürünEkleToolStripMenuItem.Text = "Ürün Ekle";
            this.ürünEkleToolStripMenuItem.Click += new System.EventHandler(this.ürünEkleToolStripMenuItem_Click);
            // 
            // ürünGüncelleToolStripMenuItem
            // 
            this.ürünGüncelleToolStripMenuItem.Image = global::AdoNet_DAL_Detayli_Proje.Properties.Resources.update;
            this.ürünGüncelleToolStripMenuItem.Name = "ürünGüncelleToolStripMenuItem";
            this.ürünGüncelleToolStripMenuItem.Size = new System.Drawing.Size(274, 26);
            this.ürünGüncelleToolStripMenuItem.Text = "Ürün Güncelle";
            this.ürünGüncelleToolStripMenuItem.Click += new System.EventHandler(this.ürünGüncelleToolStripMenuItem_Click);
            // 
            // ürünSilToolStripMenuItem
            // 
            this.ürünSilToolStripMenuItem.Image = global::AdoNet_DAL_Detayli_Proje.Properties.Resources.delete;
            this.ürünSilToolStripMenuItem.Name = "ürünSilToolStripMenuItem";
            this.ürünSilToolStripMenuItem.Size = new System.Drawing.Size(274, 26);
            this.ürünSilToolStripMenuItem.Text = "Ürün Sil";
            this.ürünSilToolStripMenuItem.Click += new System.EventHandler(this.ürünSilToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(271, 6);
            // 
            // çıkışToolStripMenuItem
            // 
            this.çıkışToolStripMenuItem.Image = global::AdoNet_DAL_Detayli_Proje.Properties.Resources.cancel;
            this.çıkışToolStripMenuItem.Name = "çıkışToolStripMenuItem";
            this.çıkışToolStripMenuItem.Size = new System.Drawing.Size(274, 26);
            this.çıkışToolStripMenuItem.Text = "Çıkış";
            this.çıkışToolStripMenuItem.Click += new System.EventHandler(this.çıkışToolStripMenuItem_Click);
            // 
            // hizalamalarToolStripMenuItem
            // 
            this.hizalamalarToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.basamaklaToolStripMenuItem,
            this.yatayHizalaToolStripMenuItem,
            this.dikeyHizalaToolStripMenuItem});
            this.hizalamalarToolStripMenuItem.Name = "hizalamalarToolStripMenuItem";
            this.hizalamalarToolStripMenuItem.Size = new System.Drawing.Size(104, 25);
            this.hizalamalarToolStripMenuItem.Text = "Hizalamalar";
            // 
            // basamaklaToolStripMenuItem
            // 
            this.basamaklaToolStripMenuItem.Name = "basamaklaToolStripMenuItem";
            this.basamaklaToolStripMenuItem.Size = new System.Drawing.Size(165, 26);
            this.basamaklaToolStripMenuItem.Text = "Basamakla";
            this.basamaklaToolStripMenuItem.Click += new System.EventHandler(this.basamaklaToolStripMenuItem_Click);
            // 
            // yatayHizalaToolStripMenuItem
            // 
            this.yatayHizalaToolStripMenuItem.Name = "yatayHizalaToolStripMenuItem";
            this.yatayHizalaToolStripMenuItem.Size = new System.Drawing.Size(165, 26);
            this.yatayHizalaToolStripMenuItem.Text = "Yatay Hizala";
            this.yatayHizalaToolStripMenuItem.Click += new System.EventHandler(this.yatayHizalaToolStripMenuItem_Click);
            // 
            // dikeyHizalaToolStripMenuItem
            // 
            this.dikeyHizalaToolStripMenuItem.Name = "dikeyHizalaToolStripMenuItem";
            this.dikeyHizalaToolStripMenuItem.Size = new System.Drawing.Size(165, 26);
            this.dikeyHizalaToolStripMenuItem.Text = "Dikey Hizala";
            this.dikeyHizalaToolStripMenuItem.Click += new System.EventHandler(this.dikeyHizalaToolStripMenuItem_Click);
            // 
            // kategoriToolStripMenuItem
            // 
            this.kategoriToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tümKategorilerToolStripMenuItem,
            this.toolStripSeparator3,
            this.yeniToolStripMenuItem1,
            this.kategoriGüncelleToolStripMenuItem,
            this.kategoriSilToolStripMenuItem,
            this.toolStripSeparator4,
            this.çıkışToolStripMenuItem1});
            this.kategoriToolStripMenuItem.Name = "kategoriToolStripMenuItem";
            this.kategoriToolStripMenuItem.Size = new System.Drawing.Size(80, 25);
            this.kategoriToolStripMenuItem.Text = "Kategori";
            // 
            // tümKategorilerToolStripMenuItem
            // 
            this.tümKategorilerToolStripMenuItem.Image = global::AdoNet_DAL_Detayli_Proje.Properties.Resources.list;
            this.tümKategorilerToolStripMenuItem.Name = "tümKategorilerToolStripMenuItem";
            this.tümKategorilerToolStripMenuItem.Size = new System.Drawing.Size(202, 26);
            this.tümKategorilerToolStripMenuItem.Text = "Tüm Kategoriler";
            this.tümKategorilerToolStripMenuItem.Click += new System.EventHandler(this.tümKategorilerToolStripMenuItem_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(199, 6);
            // 
            // yeniToolStripMenuItem1
            // 
            this.yeniToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.kategoriEkleToolStripMenuItem});
            this.yeniToolStripMenuItem1.Image = global::AdoNet_DAL_Detayli_Proje.Properties.Resources._new;
            this.yeniToolStripMenuItem1.Name = "yeniToolStripMenuItem1";
            this.yeniToolStripMenuItem1.Size = new System.Drawing.Size(202, 26);
            this.yeniToolStripMenuItem1.Text = "Yeni >>>";
            // 
            // kategoriEkleToolStripMenuItem
            // 
            this.kategoriEkleToolStripMenuItem.Name = "kategoriEkleToolStripMenuItem";
            this.kategoriEkleToolStripMenuItem.Size = new System.Drawing.Size(170, 26);
            this.kategoriEkleToolStripMenuItem.Text = "Kategori Ekle";
            this.kategoriEkleToolStripMenuItem.Click += new System.EventHandler(this.kategoriEkleToolStripMenuItem_Click);
            // 
            // kategoriGüncelleToolStripMenuItem
            // 
            this.kategoriGüncelleToolStripMenuItem.Image = global::AdoNet_DAL_Detayli_Proje.Properties.Resources.update;
            this.kategoriGüncelleToolStripMenuItem.Name = "kategoriGüncelleToolStripMenuItem";
            this.kategoriGüncelleToolStripMenuItem.Size = new System.Drawing.Size(202, 26);
            this.kategoriGüncelleToolStripMenuItem.Text = "Kategori Güncelle";
            this.kategoriGüncelleToolStripMenuItem.Click += new System.EventHandler(this.kategoriGüncelleToolStripMenuItem_Click);
            // 
            // kategoriSilToolStripMenuItem
            // 
            this.kategoriSilToolStripMenuItem.Image = global::AdoNet_DAL_Detayli_Proje.Properties.Resources.delete1;
            this.kategoriSilToolStripMenuItem.Name = "kategoriSilToolStripMenuItem";
            this.kategoriSilToolStripMenuItem.Size = new System.Drawing.Size(202, 26);
            this.kategoriSilToolStripMenuItem.Text = "Kategori Sil";
            this.kategoriSilToolStripMenuItem.Click += new System.EventHandler(this.kategoriSilToolStripMenuItem_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(199, 6);
            // 
            // çıkışToolStripMenuItem1
            // 
            this.çıkışToolStripMenuItem1.Image = global::AdoNet_DAL_Detayli_Proje.Properties.Resources.cancel;
            this.çıkışToolStripMenuItem1.Name = "çıkışToolStripMenuItem1";
            this.çıkışToolStripMenuItem1.Size = new System.Drawing.Size(202, 26);
            this.çıkışToolStripMenuItem1.Text = "Çıkış";
            this.çıkışToolStripMenuItem1.Click += new System.EventHandler(this.çıkışToolStripMenuItem_Click);
            // 
            // tedarikçilerToolStripMenuItem
            // 
            this.tedarikçilerToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tToolStripMenuItem,
            this.toolStripSeparator5,
            this.yeniToolStripMenuItem2,
            this.tedarikçiGüncelleToolStripMenuItem,
            this.tedarikçiSilToolStripMenuItem,
            this.toolStripSeparator6,
            this.çıkışToolStripMenuItem2});
            this.tedarikçilerToolStripMenuItem.Name = "tedarikçilerToolStripMenuItem";
            this.tedarikçilerToolStripMenuItem.Size = new System.Drawing.Size(102, 25);
            this.tedarikçilerToolStripMenuItem.Text = "Tedarikçiler";
            // 
            // tToolStripMenuItem
            // 
            this.tToolStripMenuItem.Image = global::AdoNet_DAL_Detayli_Proje.Properties.Resources.users_icon;
            this.tToolStripMenuItem.Name = "tToolStripMenuItem";
            this.tToolStripMenuItem.Size = new System.Drawing.Size(206, 26);
            this.tToolStripMenuItem.Text = "Tüm Tedarikçiler";
            this.tToolStripMenuItem.Click += new System.EventHandler(this.tToolStripMenuItem_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(203, 6);
            // 
            // yeniToolStripMenuItem2
            // 
            this.yeniToolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tedarikçiEkleToolStripMenuItem});
            this.yeniToolStripMenuItem2.Image = global::AdoNet_DAL_Detayli_Proje.Properties.Resources.user_add_icon;
            this.yeniToolStripMenuItem2.Name = "yeniToolStripMenuItem2";
            this.yeniToolStripMenuItem2.Size = new System.Drawing.Size(206, 26);
            this.yeniToolStripMenuItem2.Text = "Yeni >>>";
            // 
            // tedarikçiEkleToolStripMenuItem
            // 
            this.tedarikçiEkleToolStripMenuItem.Name = "tedarikçiEkleToolStripMenuItem";
            this.tedarikçiEkleToolStripMenuItem.Size = new System.Drawing.Size(174, 26);
            this.tedarikçiEkleToolStripMenuItem.Text = "Tedarikçi Ekle";
            this.tedarikçiEkleToolStripMenuItem.Click += new System.EventHandler(this.tedarikçiEkleToolStripMenuItem_Click);
            // 
            // tedarikçiGüncelleToolStripMenuItem
            // 
            this.tedarikçiGüncelleToolStripMenuItem.Image = global::AdoNet_DAL_Detayli_Proje.Properties.Resources.user_update_icon;
            this.tedarikçiGüncelleToolStripMenuItem.Name = "tedarikçiGüncelleToolStripMenuItem";
            this.tedarikçiGüncelleToolStripMenuItem.Size = new System.Drawing.Size(206, 26);
            this.tedarikçiGüncelleToolStripMenuItem.Text = "Tedarikçi Güncelle";
            this.tedarikçiGüncelleToolStripMenuItem.Click += new System.EventHandler(this.tedarikçiGüncelleToolStripMenuItem_Click);
            // 
            // tedarikçiSilToolStripMenuItem
            // 
            this.tedarikçiSilToolStripMenuItem.Image = global::AdoNet_DAL_Detayli_Proje.Properties.Resources.user_remove_icon;
            this.tedarikçiSilToolStripMenuItem.Name = "tedarikçiSilToolStripMenuItem";
            this.tedarikçiSilToolStripMenuItem.Size = new System.Drawing.Size(206, 26);
            this.tedarikçiSilToolStripMenuItem.Text = "Tedarikçi Sil";
            this.tedarikçiSilToolStripMenuItem.Click += new System.EventHandler(this.tedarikçiSilToolStripMenuItem_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(203, 6);
            // 
            // çıkışToolStripMenuItem2
            // 
            this.çıkışToolStripMenuItem2.Image = global::AdoNet_DAL_Detayli_Proje.Properties.Resources.cancel;
            this.çıkışToolStripMenuItem2.Name = "çıkışToolStripMenuItem2";
            this.çıkışToolStripMenuItem2.Size = new System.Drawing.Size(206, 26);
            this.çıkışToolStripMenuItem2.Text = "Çıkış";
            this.çıkışToolStripMenuItem2.Click += new System.EventHandler(this.çıkışToolStripMenuItem_Click);
            // 
            // siparişlerToolStripMenuItem
            // 
            this.siparişlerToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tümSiparişToolStripMenuItem,
            this.toolStripSeparator7,
            this.yeniToolStripMenuItem3,
            this.siparişGüncelleToolStripMenuItem,
            this.siparişSilToolStripMenuItem,
            this.toolStripSeparator8,
            this.çıkışToolStripMenuItem3});
            this.siparişlerToolStripMenuItem.Name = "siparişlerToolStripMenuItem";
            this.siparişlerToolStripMenuItem.Size = new System.Drawing.Size(87, 25);
            this.siparişlerToolStripMenuItem.Text = "Siparişler";
            // 
            // tümSiparişToolStripMenuItem
            // 
            this.tümSiparişToolStripMenuItem.Image = global::AdoNet_DAL_Detayli_Proje.Properties.Resources.list;
            this.tümSiparişToolStripMenuItem.Name = "tümSiparişToolStripMenuItem";
            this.tümSiparişToolStripMenuItem.Size = new System.Drawing.Size(191, 26);
            this.tümSiparişToolStripMenuItem.Text = "Tüm Sipariş";
            this.tümSiparişToolStripMenuItem.Click += new System.EventHandler(this.tümSiparişToolStripMenuItem_Click);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(188, 6);
            // 
            // yeniToolStripMenuItem3
            // 
            this.yeniToolStripMenuItem3.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.siparişEkleToolStripMenuItem});
            this.yeniToolStripMenuItem3.Image = global::AdoNet_DAL_Detayli_Proje.Properties.Resources._new;
            this.yeniToolStripMenuItem3.Name = "yeniToolStripMenuItem3";
            this.yeniToolStripMenuItem3.Size = new System.Drawing.Size(191, 26);
            this.yeniToolStripMenuItem3.Text = "Yeni >>>";
            // 
            // siparişEkleToolStripMenuItem
            // 
            this.siparişEkleToolStripMenuItem.Name = "siparişEkleToolStripMenuItem";
            this.siparişEkleToolStripMenuItem.Size = new System.Drawing.Size(180, 26);
            this.siparişEkleToolStripMenuItem.Text = "Sipariş Ekle";
            this.siparişEkleToolStripMenuItem.Click += new System.EventHandler(this.siparişEkleToolStripMenuItem_Click);
            // 
            // siparişGüncelleToolStripMenuItem
            // 
            this.siparişGüncelleToolStripMenuItem.Image = global::AdoNet_DAL_Detayli_Proje.Properties.Resources.update;
            this.siparişGüncelleToolStripMenuItem.Name = "siparişGüncelleToolStripMenuItem";
            this.siparişGüncelleToolStripMenuItem.Size = new System.Drawing.Size(191, 26);
            this.siparişGüncelleToolStripMenuItem.Text = "Sipariş Güncelle";
            this.siparişGüncelleToolStripMenuItem.Click += new System.EventHandler(this.siparişGüncelleToolStripMenuItem_Click);
            // 
            // siparişSilToolStripMenuItem
            // 
            this.siparişSilToolStripMenuItem.Image = global::AdoNet_DAL_Detayli_Proje.Properties.Resources.delete1;
            this.siparişSilToolStripMenuItem.Name = "siparişSilToolStripMenuItem";
            this.siparişSilToolStripMenuItem.Size = new System.Drawing.Size(191, 26);
            this.siparişSilToolStripMenuItem.Text = "Sipariş Sil";
            this.siparişSilToolStripMenuItem.Click += new System.EventHandler(this.siparişSilToolStripMenuItem_Click);
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(188, 6);
            // 
            // çıkışToolStripMenuItem3
            // 
            this.çıkışToolStripMenuItem3.Image = global::AdoNet_DAL_Detayli_Proje.Properties.Resources.cancel;
            this.çıkışToolStripMenuItem3.Name = "çıkışToolStripMenuItem3";
            this.çıkışToolStripMenuItem3.Size = new System.Drawing.Size(191, 26);
            this.çıkışToolStripMenuItem3.Text = "Çıkış";
            this.çıkışToolStripMenuItem3.Click += new System.EventHandler(this.çıkışToolStripMenuItem_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabelDurum});
            this.statusStrip1.Location = new System.Drawing.Point(0, 457);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(838, 22);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabelDurum
            // 
            this.toolStripStatusLabelDurum.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Italic);
            this.toolStripStatusLabelDurum.Name = "toolStripStatusLabelDurum";
            this.toolStripStatusLabelDurum.Size = new System.Drawing.Size(0, 17);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(838, 479);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStripVeriler);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStripVeriler;
            this.Name = "frmMain";
            this.Text = "AdoNet Northwind - Products Project";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.menuStripVeriler.ResumeLayout(false);
            this.menuStripVeriler.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStripVeriler;
        private System.Windows.Forms.ToolStripMenuItem ürünlerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tümÜrünleriListeleToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem yeniToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ürünEkleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ürünGüncelleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ürünSilToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem çıkışToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hizalamalarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem basamaklaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem yatayHizalaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dikeyHizalaToolStripMenuItem;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabelDurum;
        private System.Windows.Forms.ToolStripMenuItem kategoriToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tedarikçilerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem siparişlerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tümKategorilerToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem yeniToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem kategoriEkleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kategoriGüncelleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kategoriSilToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem çıkışToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem tToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripMenuItem yeniToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem tedarikçiEkleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tedarikçiGüncelleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tedarikçiSilToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripMenuItem çıkışToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem tümSiparişToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripMenuItem yeniToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem siparişEkleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem siparişGüncelleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem siparişSilToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripMenuItem çıkışToolStripMenuItem3;
    }
}

