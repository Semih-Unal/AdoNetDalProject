﻿namespace AdoNet_DAL_Detayli_Proje.Orders
{
    partial class frmGuncelle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.nUdUpdateFreight = new System.Windows.Forms.NumericUpDown();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cbUpdateEmployee = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.cbUpdateShippers = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.cbUpdateCustomer = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.dTpUpdateShippedDate = new System.Windows.Forms.DateTimePicker();
            this.dTpUpdateRequiredDate = new System.Windows.Forms.DateTimePicker();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.dTpUpdateOrderDate = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.txtUpdateShipCountry = new System.Windows.Forms.TextBox();
            this.txtUpdateShipPostalCode = new System.Windows.Forms.TextBox();
            this.txtUpdateShipRegion = new System.Windows.Forms.TextBox();
            this.txtUpdateShipCity = new System.Windows.Forms.TextBox();
            this.txtUpdateShipAddress = new System.Windows.Forms.TextBox();
            this.txtUpdateShipName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.lstOrders = new System.Windows.Forms.ListBox();
            ((System.ComponentModel.ISupportInitialize)(this.nUdUpdateFreight)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // nUdUpdateFreight
            // 
            this.nUdUpdateFreight.DecimalPlaces = 3;
            this.nUdUpdateFreight.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.nUdUpdateFreight.Increment = new decimal(new int[] {
            1010,
            0,
            0,
            131072});
            this.nUdUpdateFreight.Location = new System.Drawing.Point(199, 324);
            this.nUdUpdateFreight.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.nUdUpdateFreight.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nUdUpdateFreight.Name = "nUdUpdateFreight";
            this.nUdUpdateFreight.Size = new System.Drawing.Size(287, 30);
            this.nUdUpdateFreight.TabIndex = 28;
            this.nUdUpdateFreight.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.groupBox1.Controls.Add(this.cbUpdateEmployee);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.cbUpdateShippers);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.cbUpdateCustomer);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox1.Location = new System.Drawing.Point(27, 531);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(459, 148);
            this.groupBox1.TabIndex = 27;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Seçiniz";
            // 
            // cbUpdateEmployee
            // 
            this.cbUpdateEmployee.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbUpdateEmployee.FormattingEnabled = true;
            this.cbUpdateEmployee.Location = new System.Drawing.Point(143, 97);
            this.cbUpdateEmployee.Name = "cbUpdateEmployee";
            this.cbUpdateEmployee.Size = new System.Drawing.Size(258, 28);
            this.cbUpdateEmployee.TabIndex = 3;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label13.Location = new System.Drawing.Point(22, 100);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(91, 20);
            this.label13.TabIndex = 2;
            this.label13.Text = "Employee : ";
            // 
            // cbUpdateShippers
            // 
            this.cbUpdateShippers.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbUpdateShippers.FormattingEnabled = true;
            this.cbUpdateShippers.Location = new System.Drawing.Point(143, 63);
            this.cbUpdateShippers.Name = "cbUpdateShippers";
            this.cbUpdateShippers.Size = new System.Drawing.Size(258, 28);
            this.cbUpdateShippers.TabIndex = 3;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label12.Location = new System.Drawing.Point(22, 66);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(84, 20);
            this.label12.TabIndex = 2;
            this.label12.Text = "Shippers : ";
            // 
            // cbUpdateCustomer
            // 
            this.cbUpdateCustomer.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbUpdateCustomer.FormattingEnabled = true;
            this.cbUpdateCustomer.Location = new System.Drawing.Point(143, 29);
            this.cbUpdateCustomer.Name = "cbUpdateCustomer";
            this.cbUpdateCustomer.Size = new System.Drawing.Size(258, 28);
            this.cbUpdateCustomer.TabIndex = 3;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label11.Location = new System.Drawing.Point(22, 32);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(94, 20);
            this.label11.TabIndex = 2;
            this.label11.Text = "Customer  : ";
            // 
            // dTpUpdateShippedDate
            // 
            this.dTpUpdateShippedDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.dTpUpdateShippedDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dTpUpdateShippedDate.Location = new System.Drawing.Point(199, 289);
            this.dTpUpdateShippedDate.Name = "dTpUpdateShippedDate";
            this.dTpUpdateShippedDate.Size = new System.Drawing.Size(287, 26);
            this.dTpUpdateShippedDate.TabIndex = 25;
            // 
            // dTpUpdateRequiredDate
            // 
            this.dTpUpdateRequiredDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.dTpUpdateRequiredDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dTpUpdateRequiredDate.Location = new System.Drawing.Point(199, 246);
            this.dTpUpdateRequiredDate.Name = "dTpUpdateRequiredDate";
            this.dTpUpdateRequiredDate.Size = new System.Drawing.Size(287, 26);
            this.dTpUpdateRequiredDate.TabIndex = 24;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label10.Location = new System.Drawing.Point(22, 489);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(108, 20);
            this.label10.TabIndex = 16;
            this.label10.Text = "ShipCountry : ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label9.Location = new System.Drawing.Point(22, 457);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(135, 20);
            this.label9.TabIndex = 15;
            this.label9.Text = "ShipPostalCode : ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.Location = new System.Drawing.Point(22, 425);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(104, 20);
            this.label8.TabIndex = 17;
            this.label8.Text = "ShipRegion : ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.Location = new System.Drawing.Point(22, 393);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(79, 20);
            this.label7.TabIndex = 13;
            this.label7.Text = "ShipCity : ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.Location = new System.Drawing.Point(22, 361);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(112, 20);
            this.label6.TabIndex = 12;
            this.label6.Text = "ShipAddress : ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.Location = new System.Drawing.Point(22, 324);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(71, 20);
            this.label5.TabIndex = 11;
            this.label5.Text = "Freight : ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.Location = new System.Drawing.Point(22, 289);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(115, 20);
            this.label4.TabIndex = 8;
            this.label4.Text = "ShippedDate : ";
            // 
            // dTpUpdateOrderDate
            // 
            this.dTpUpdateOrderDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.dTpUpdateOrderDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dTpUpdateOrderDate.Location = new System.Drawing.Point(199, 208);
            this.dTpUpdateOrderDate.Name = "dTpUpdateOrderDate";
            this.dTpUpdateOrderDate.Size = new System.Drawing.Size(287, 26);
            this.dTpUpdateOrderDate.TabIndex = 26;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(22, 246);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(121, 20);
            this.label3.TabIndex = 9;
            this.label3.Text = "RequiredDate : ";
            // 
            // txtUpdateShipCountry
            // 
            this.txtUpdateShipCountry.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtUpdateShipCountry.Location = new System.Drawing.Point(199, 489);
            this.txtUpdateShipCountry.MaxLength = 40;
            this.txtUpdateShipCountry.Name = "txtUpdateShipCountry";
            this.txtUpdateShipCountry.Size = new System.Drawing.Size(287, 26);
            this.txtUpdateShipCountry.TabIndex = 18;
            // 
            // txtUpdateShipPostalCode
            // 
            this.txtUpdateShipPostalCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtUpdateShipPostalCode.Location = new System.Drawing.Point(199, 457);
            this.txtUpdateShipPostalCode.MaxLength = 40;
            this.txtUpdateShipPostalCode.Name = "txtUpdateShipPostalCode";
            this.txtUpdateShipPostalCode.Size = new System.Drawing.Size(287, 26);
            this.txtUpdateShipPostalCode.TabIndex = 19;
            // 
            // txtUpdateShipRegion
            // 
            this.txtUpdateShipRegion.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtUpdateShipRegion.Location = new System.Drawing.Point(199, 425);
            this.txtUpdateShipRegion.MaxLength = 40;
            this.txtUpdateShipRegion.Name = "txtUpdateShipRegion";
            this.txtUpdateShipRegion.Size = new System.Drawing.Size(287, 26);
            this.txtUpdateShipRegion.TabIndex = 20;
            // 
            // txtUpdateShipCity
            // 
            this.txtUpdateShipCity.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtUpdateShipCity.Location = new System.Drawing.Point(199, 393);
            this.txtUpdateShipCity.MaxLength = 40;
            this.txtUpdateShipCity.Name = "txtUpdateShipCity";
            this.txtUpdateShipCity.Size = new System.Drawing.Size(287, 26);
            this.txtUpdateShipCity.TabIndex = 21;
            // 
            // txtUpdateShipAddress
            // 
            this.txtUpdateShipAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtUpdateShipAddress.Location = new System.Drawing.Point(199, 361);
            this.txtUpdateShipAddress.MaxLength = 40;
            this.txtUpdateShipAddress.Name = "txtUpdateShipAddress";
            this.txtUpdateShipAddress.Size = new System.Drawing.Size(287, 26);
            this.txtUpdateShipAddress.TabIndex = 22;
            // 
            // txtUpdateShipName
            // 
            this.txtUpdateShipName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtUpdateShipName.Location = new System.Drawing.Point(199, 171);
            this.txtUpdateShipName.MaxLength = 40;
            this.txtUpdateShipName.Name = "txtUpdateShipName";
            this.txtUpdateShipName.Size = new System.Drawing.Size(287, 26);
            this.txtUpdateShipName.TabIndex = 23;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(22, 208);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 20);
            this.label2.TabIndex = 10;
            this.label2.Text = "OrderDate : ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(22, 177);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 20);
            this.label1.TabIndex = 14;
            this.label1.Text = "ShipName : ";
            // 
            // btnUpdate
            // 
            this.btnUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnUpdate.Image = global::AdoNet_DAL_Detayli_Proje.Properties.Resources.update_icon;
            this.btnUpdate.Location = new System.Drawing.Point(312, 691);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(174, 51);
            this.btnUpdate.TabIndex = 29;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnUpdate.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // lstOrders
            // 
            this.lstOrders.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lstOrders.ForeColor = System.Drawing.Color.Blue;
            this.lstOrders.FormattingEnabled = true;
            this.lstOrders.ItemHeight = 20;
            this.lstOrders.Location = new System.Drawing.Point(12, 2);
            this.lstOrders.Name = "lstOrders";
            this.lstOrders.Size = new System.Drawing.Size(474, 164);
            this.lstOrders.TabIndex = 30;
            this.lstOrders.SelectedIndexChanged += new System.EventHandler(this.lstOrders_SelectedIndexChanged);
            // 
            // frmGuncelle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(514, 750);
            this.Controls.Add(this.lstOrders);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.nUdUpdateFreight);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dTpUpdateShippedDate);
            this.Controls.Add(this.dTpUpdateRequiredDate);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.dTpUpdateOrderDate);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtUpdateShipCountry);
            this.Controls.Add(this.txtUpdateShipPostalCode);
            this.Controls.Add(this.txtUpdateShipRegion);
            this.Controls.Add(this.txtUpdateShipCity);
            this.Controls.Add(this.txtUpdateShipAddress);
            this.Controls.Add(this.txtUpdateShipName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "frmGuncelle";
            this.Text = "- Sipariş Güncelleme -";
            this.Load += new System.EventHandler(this.frmGuncelle_Load);
            ((System.ComponentModel.ISupportInitialize)(this.nUdUpdateFreight)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.NumericUpDown nUdUpdateFreight;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cbUpdateEmployee;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox cbUpdateShippers;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox cbUpdateCustomer;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DateTimePicker dTpUpdateShippedDate;
        private System.Windows.Forms.DateTimePicker dTpUpdateRequiredDate;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker dTpUpdateOrderDate;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtUpdateShipCountry;
        private System.Windows.Forms.TextBox txtUpdateShipPostalCode;
        private System.Windows.Forms.TextBox txtUpdateShipRegion;
        private System.Windows.Forms.TextBox txtUpdateShipCity;
        private System.Windows.Forms.TextBox txtUpdateShipAddress;
        private System.Windows.Forms.TextBox txtUpdateShipName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.ListBox lstOrders;
    }
}