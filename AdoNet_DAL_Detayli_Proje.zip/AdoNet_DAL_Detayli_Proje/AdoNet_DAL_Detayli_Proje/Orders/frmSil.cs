﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdoNet_DAL_Detayli_Proje.Orders
{
    public partial class frmSil : Form
    {
        public frmSil()
        {
            InitializeComponent();
        }

        private void frmSil_Load(object sender, EventArgs e)
        {
            OrdersFill();
        }
        DAL.OrderDal orderDal = new DAL.OrderDal();
        private void OrdersFill()
        {
            dGwOrders.Rows.Clear();
            List<Entity.Orders> urunler = orderDal.List();

            dGwOrders.DataSource = urunler;
            this.Text = "- Sipariş Silme - " + dGwOrders.Rows.Count.ToString() + " Adet Ürün Listelenmiştir.";
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Silmek İstediğinize Emin Misiniz?", "Silme İşlemi", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == DialogResult.Yes)
            {
                int result = orderDal.Delete(dGwOrders.Rows[0].Cells[13].Value);

                if (result != 0)
                {
                    MessageBox.Show("Silme İşleminiz Başarılı Şekilde Gerçekleşmiştir.");
                    this.Close();
                    Orders.frmListele yavruList = new Orders.frmListele();
                    //yavruList.MdiParent = this;
                    yavruList.Show();
                }
            }
        }
    }
}
