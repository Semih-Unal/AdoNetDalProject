﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdoNet_DAL_Detayli_Proje.Orders
{
    public partial class frmListele : Form
    {
        public frmListele()
        {
            InitializeComponent();
        }

        private void frmListele_Load(object sender, EventArgs e)
        {

            OrdersFill();
        }
        DAL.OrderDal oDal = new DAL.OrderDal();
        private void OrdersFill()
        {
            lstwOrders.Items.Clear();
            List<Entity.Orders> siparisler = oDal.List();

            foreach (Entity.Orders o in siparisler)
            {
                ListViewItem li = new ListViewItem();
                li.Tag = o;
                li.Text = o.ShipName;
                li.SubItems.Add(o.OrderDate.ToString());
                li.SubItems.Add(o.RequiredDate.ToString());
                li.SubItems.Add(o.ShippedDate.ToString());
                li.SubItems.Add(o.Freight.ToString());
                li.SubItems.Add(o.ShipAddress.ToString());
                li.SubItems.Add(o.ShipCity.ToString());
                li.SubItems.Add(o.ShipRegion.ToString());
                li.SubItems.Add(o.ShipPostalCode.ToString());
                li.SubItems.Add(o.ShipCountry.ToString());
                //------------------------------------
                li.SubItems.Add(o.CustomerID.ToString());
                li.SubItems.Add(o.EmployeeID.ToString());
                li.SubItems.Add(o.ShipVia.ToString());

                lstwOrders.Items.Add(li);

            }
            toolStripStatusLabelVeriler.Text = lstwOrders.Items.Count.ToString() + " Adet Sipariş Listelenmiştir...";
        }
    }
}
