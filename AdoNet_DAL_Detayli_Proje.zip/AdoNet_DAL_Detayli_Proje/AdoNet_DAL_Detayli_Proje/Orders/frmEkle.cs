﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace AdoNet_DAL_Detayli_Proje.Orders
{
    public partial class frmEkle : Form
    {
        public frmEkle()
        {
            InitializeComponent();
        }
        SqlConnection cnn = new SqlConnection(Properties.Settings.Default.SqlConString);
        private void frmEkle_Load(object sender, EventArgs e)
        {
            CustomerFill();
            
            ShippersFill();

            EmployeesFill();
        }

        private void EmployeesFill()
        {
            cbEmployee.Items.Clear();

            SqlCommand cmd = new SqlCommand("Select * From Employees", cnn);

            try
            {
                if (cnn.State == ConnectionState.Closed)
                    cnn.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Entity.Employees emps = new Entity.Employees();
                        emps.id = Convert.ToInt32(reader["EmployeeID"]);
                        emps.FirstName = reader["FirstName"].ToString();
                        emps.LastName = reader["LastName"].ToString();

                        cbEmployee.Items.Add(emps);
                    }
                }
                cbEmployee.SelectedIndex = 0;
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ey)
            {
                MessageBox.Show(ey.Message);
            }
            finally
            {
                cnn.Close();
            }
        }

        private void ShippersFill()
        {
            cbShippers.Items.Clear();

            SqlCommand cmd = new SqlCommand("Select * From Shippers", cnn);

            try
            {
                if (cnn.State == ConnectionState.Closed)
                    cnn.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Entity.Shippers ships = new Entity.Shippers();
                        ships.id = Convert.ToInt32(reader["ShipperID"]);
                        ships.CompanyName = reader["CompanyName"].ToString();

                        cbShippers.Items.Add(ships);
                    }
                }
                cbShippers.SelectedIndex = 0;
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ey)
            {
                MessageBox.Show(ey.Message);
            }
            finally
            {
                cnn.Close();
            }
        }

        private void CustomerFill()
        {
            cbCustomer.Items.Clear();

            SqlCommand cmd = new SqlCommand("Select * From Customers",cnn);

            try
            {
                if (cnn.State == ConnectionState.Closed)
                    cnn.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Entity.Customers cust = new Entity.Customers();
                        cust.CustomerID = reader["CustomerID"].ToString();
                        cust.CompanyName = reader["CompanyName"].ToString();

                        cbCustomer.Items.Add(cust);
                    }
                }
                cbCustomer.SelectedIndex = 0;
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ey)
            {
                MessageBox.Show(ey.Message);
            }
            finally
            {
                cnn.Close();
            }


        }

        DAL.OrderDal orderDal = new DAL.OrderDal();
        private void btnSave_Click(object sender, EventArgs e)
        {
            Entity.Orders order = new Entity.Orders();

            order.ShipName = txtShipName.Text;
            order.OrderDate = dTpOrderDate.Text;
            order.RequiredDate = dTpRequiredDate.Text;
            order.ShippedDate = dTpShippedDate.Text;
            order.Freight = Convert.ToDecimal(nUdFreight.Value);
            order.ShipAddress = txtShipAddress.Text;
            order.ShipRegion = txtShipRegion.Text;
            order.ShipPostalCode = txtShipPostalCode.Text;
            order.ShipCity = txtShipCity.Text;
            order.ShipCountry = txtShipCountry.Text;
            //-----------------------------------------------
            Entity.Customers secilenCustomer = cbCustomer.SelectedItem as Entity.Customers;
            order.CustomerID = secilenCustomer.CustomerID;
            //----------
            Entity.Employees secilenEmployee = cbEmployee.SelectedItem as Entity.Employees;
            order.EmployeeID = secilenEmployee.id;
            //---------------
            Entity.Shippers secilenShipper = cbShippers.SelectedItem as Entity.Shippers;
            order.ShipVia = secilenShipper.id;

            
            int sonuc = orderDal.Save(order);
            if (sonuc != 0)
            {
                MessageBox.Show("Kaydetme İşleminiz Başarılı Şekilde Gerçekleşmiştir.");
                this.Close();
                Orders.frmListele yavruList = new Orders.frmListele();
                //yavruList.MdiParent = this;
                yavruList.Show();
            }
        }
    }
}
