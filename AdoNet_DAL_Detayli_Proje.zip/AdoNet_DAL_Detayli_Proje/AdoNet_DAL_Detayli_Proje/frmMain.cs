﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdoNet_DAL_Detayli_Proje
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            // 1. Ana Formun (IsMdiContainer) arka rengini değiştirelim ... 

            //foreach (Control c in this.Controls)
            //{
            //    c.BackColor = Color.FromArgb(128, 128, 255);  
            //}

            // 2. Projeme - Products adında Folder ekleyip - içine yavru formlarımı tasarlayacağım .. ve IEntity geçiyorum
        }

        #region Ürünler
        private void tümÜrünleriListeleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Products.frmListele yavruFormListele = new Products.frmListele();
            yavruFormListele.MdiParent = this;
            yavruFormListele.Show();
            toolStripStatusLabelDurum.Text = "Ürünleriniz Listelenmiştir...";
        }

        private void ürünEkleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Products.frmEkle yavruFormEkle = new Products.frmEkle();
            yavruFormEkle.MdiParent = this;
            yavruFormEkle.Show();
        }

        private void ürünGüncelleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Products.frmGuncelle yavruFormGüncelle = new Products.frmGuncelle();
            yavruFormGüncelle.MdiParent = this;
            yavruFormGüncelle.Show();
        }

        private void ürünSilToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Products.frmSil yavruFormSil = new Products.frmSil();
            yavruFormSil.MdiParent = this;
            yavruFormSil.Show();
        }

        private void çıkışToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        } 
        #endregion

        #region Kategoriler
        private void tümKategorilerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Categories.frmListele yavruFormListele = new Categories.frmListele();
            yavruFormListele.MdiParent = this;
            yavruFormListele.Show();
            toolStripStatusLabelDurum.Text = "Kategoriler Listelenmiştir...";
        }

        private void kategoriEkleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Categories.frmEkle yavruFormEkle = new Categories.frmEkle();
            yavruFormEkle.MdiParent = this;
            yavruFormEkle.Show();
        }

        private void kategoriGüncelleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Categories.frmGuncelle yavruFormGüncelle = new Categories.frmGuncelle();
            yavruFormGüncelle.MdiParent = this;
            yavruFormGüncelle.Show();
        }

        private void kategoriSilToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Categories.frmSil yavruFormSil = new Categories.frmSil();
            yavruFormSil.MdiParent = this;
            yavruFormSil.Show();
        }

        #endregion

        #region Tedarikçiler
        private void tToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Suppliers.frmListele yavruFormListele = new Suppliers.frmListele();
            yavruFormListele.MdiParent = this;
            yavruFormListele.Show();
            toolStripStatusLabelDurum.Text = "Tedarikçiler Listelenmiştir...";
        }

        private void tedarikçiEkleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Suppliers.frmEkle yavruFormEkle = new Suppliers.frmEkle();
            yavruFormEkle.MdiParent = this;
            yavruFormEkle.Show();
        }

        private void tedarikçiGüncelleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Suppliers.frmGuncelle yavruFormGüncelle = new Suppliers.frmGuncelle();
            yavruFormGüncelle.MdiParent = this;
            yavruFormGüncelle.Show();
        }

        private void tedarikçiSilToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Suppliers.frmSil yavruFormSil = new Suppliers.frmSil();
            yavruFormSil.MdiParent = this;
            yavruFormSil.Show();
        }
        #endregion

        #region Hizalamalar
        private void basamaklaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.Cascade);
        }

        private void yatayHizalaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileHorizontal);
        }

        private void dikeyHizalaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileVertical);
        }
        #endregion

        #region Siparişler
        private void tümSiparişToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Orders.frmListele yavruFormListele = new Orders.frmListele();
            yavruFormListele.MdiParent = this;
            yavruFormListele.Show();
            toolStripStatusLabelDurum.Text = "Siparişler Listelenmiştir...";
        }

        private void siparişEkleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Orders.frmEkle yavruFormEkle = new Orders.frmEkle();
            yavruFormEkle.MdiParent = this;
            yavruFormEkle.Show();
        }

        private void siparişGüncelleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Orders.frmGuncelle yavruFormGüncelle = new Orders.frmGuncelle();
            yavruFormGüncelle.MdiParent = this;
            yavruFormGüncelle.Show();
        }

        private void siparişSilToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Orders.frmSil yavruFormSil = new Orders.frmSil();
            yavruFormSil.MdiParent = this;
            yavruFormSil.Show();
        } 
        #endregion
    }
}
