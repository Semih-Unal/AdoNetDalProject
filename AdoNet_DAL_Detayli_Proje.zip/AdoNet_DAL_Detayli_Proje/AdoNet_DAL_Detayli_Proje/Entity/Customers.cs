﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdoNet_DAL_Detayli_Proje.Entity
{
    public class Customers : Entity
    {
        public string CustomerID { get; set; }
        public string CompanyName { get; set; }

        public override string ToString()
        {
            return this.CompanyName;
        }
    }
}
