﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdoNet_DAL_Detayli_Proje.Entity
{
    // 6. Product.cs den geldim
    public class Category : Entity
    {
        //public int CategoryID { get; set; } 
        // ID -> CategoryID -> Kalıtımdan (IEntity) üzerinden geleceke burada tekrar tanımlamaya gerek kalmadı
        public string CategoryName { get; set; }
        public string Description { get; set; }

        public override string ToString()
        {
            return this.CategoryName;
            //return this.id.ToString(); base classtan geliyor
        }
        // Not : bu tabloda karşılığı olan classım ile form tarafını iletişime geçirmek için ara katman bir folder daha açıyorum ve adına DAL (Data Access Layer - Veri Erişim Katmanı) diyorum... burada tüm tablolar için ortak olan CRUD işlemlerini vb. tanımlayacağım ... DAL kalsörü içine "DataAccessLayer" adında class oluşturcağım oradayım...

    }
}
