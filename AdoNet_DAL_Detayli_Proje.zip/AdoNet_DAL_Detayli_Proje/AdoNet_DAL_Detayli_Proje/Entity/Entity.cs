﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdoNet_DAL_Detayli_Proje.Entity
{
    public class Entity : IEntity
    {
        // 4. IEntity içinden geldim
        public int id { get; set; }

        // Entity kalsörü içine hangi tabloda çalışıyorsak (Products) onun classını açalım, oraya geçiyorum ..
    }
}
