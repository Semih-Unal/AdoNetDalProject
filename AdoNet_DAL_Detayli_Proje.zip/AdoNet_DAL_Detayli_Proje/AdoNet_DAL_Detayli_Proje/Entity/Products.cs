﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdoNet_DAL_Detayli_Proje.Entity
{
    // 5. Entity.cs'den geldim ...

    public class Products : Entity
    {
        //public int ProductID { get; set; } 
        // ID -> ProductID -> Kalıtımdan (IEntity) üzerinden geleceke burada tekrar tanımlamaya gerek kalmadı

        //--------------------------
        public string ProductName { get; set; }
        public decimal UnitPrice { get; set; }
        public int UnitsInStock { get; set; }
        public int UnitsOnOrder { get; set; }
        public bool Discontinued { get; set; } // 0 veya 1
        //--------------------------------------
        public int CategoryID { get; set; }
        public int SupplierID { get; set; }
        //------------------------
        public override string ToString()
        {
            return this.ProductName;
        }

        // Entity içine birde Category tablosu için Category.s classını açıyorum ...
    }
}
