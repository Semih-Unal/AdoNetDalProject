﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdoNet_DAL_Detayli_Proje.Entity
{
    interface IEntity // tüm tablolarda ortak olan alanları bu base (ana) class üzerinden kalıtım verdireceğim ...
    {
        // 3. Main'den Geliyorum ..

        int id { get; set; }

        // bu interfase kalıtım alan bir Entity klasörünün içine ... oradayım ...
    }
}
