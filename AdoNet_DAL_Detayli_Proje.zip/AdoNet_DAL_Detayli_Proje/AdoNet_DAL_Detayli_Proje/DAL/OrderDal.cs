﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using AdoNet_DAL_Detayli_Proje.Entity;

namespace AdoNet_DAL_Detayli_Proje.DAL
{
    public class OrderDal : DataAccessLayer<Entity.Orders>
    {
        SqlConnection cnn = new SqlConnection(Properties.Settings.Default.SqlConString);
        SqlCommand cmd;
        SqlDataReader reader;

        public override int Delete(object instanceId)
        {
            cmd = new SqlCommand("pr_ordersdelete", cnn);
            cmd.CommandType = CommandType.StoredProcedure;
            //---------------
            cmd.Parameters.AddWithValue("@OrderID", Convert.ToInt32(instanceId));
            //cmd.Parameters.AddWithValue("@CustomerID", customerId);

            //-----------------------------
            int sonuc = 0;
            try
            {
                if (cnn.State == ConnectionState.Closed)
                    cnn.Open();
                sonuc = cmd.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            catch (Exception ey)
            {
                System.Windows.Forms.MessageBox.Show(ey.Message);
            }
            finally
            {
                cnn.Close();
            }
            return sonuc;
        }

        public override List<Entity.Orders> List()
        {
            cmd = new SqlCommand("pr_orderslist",cnn);
            cmd.CommandType = CommandType.StoredProcedure;

            List<Entity.Orders> siparisler = new List<Entity.Orders>();
            try
            {
                if (cnn.State == ConnectionState.Closed)
                    cnn.Open();
                reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Entity.Orders order = new Entity.Orders();
                        order.id = Convert.ToInt32(reader["OrderID"].ToString()); // Kalıtımdan geldi...
                        //-------------------------------
                        order.ShipName = reader["ShipName"].ToString();
                        order.OrderDate = reader["OrderDate"].ToString();
                        order.RequiredDate = reader["RequiredDate"].ToString();
                        order.ShippedDate = reader["ShippedDate"].ToString();
                        order.Freight = Convert.ToDecimal(reader["Freight"]);
                        order.ShipAddress = reader["ShipAddress"].ToString();
                        order.ShipRegion = reader["ShipRegion"].ToString();
                        order.ShipPostalCode = reader["ShipPostalCode"].ToString();
                        order.ShipCity = reader["ShipCity"].ToString();
                        order.ShipCountry = reader["ShipCountry"].ToString();
                        //-----------------------------------------------
                        order.CustomerID = reader["CustomerID"].ToString();
                        order.EmployeeID = Convert.ToInt32(reader["EmployeeID"]);
                        order.ShipVia = Convert.ToInt32(reader["ShipVia"]);
                        siparisler.Add(order);
                    }
                }
            }
            catch (SqlException ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            catch (Exception ey)
            {
                System.Windows.Forms.MessageBox.Show(ey.Message);
            }
            finally
            {
                cnn.Close();
            }
            return siparisler;
        }

        public override Entity.Orders Load(object instanceId)
        {
            throw new NotImplementedException();
        }

        public override int Save(Entity.Orders instance)
        {
            cmd = new SqlCommand("pr_orderssave", cnn);
            cmd.CommandType = CommandType.StoredProcedure;
            //---------------
            cmd.Parameters.AddWithValue("@ShipName", instance.ShipName);
            cmd.Parameters.AddWithValue("@OrderDate", instance.OrderDate);
            cmd.Parameters.AddWithValue("@RequiredDate", instance.RequiredDate);
            cmd.Parameters.AddWithValue("@ShippedDate", instance.ShippedDate);
            cmd.Parameters.AddWithValue("@Freight", instance.Freight);
            cmd.Parameters.AddWithValue("@ShipAddress", instance.ShipAddress);
            cmd.Parameters.AddWithValue("@ShipRegion", instance.ShipRegion);
            cmd.Parameters.AddWithValue("@ShipPostalCode", instance.ShipPostalCode);
            cmd.Parameters.AddWithValue("@ShipCity", instance.ShipCity);
            cmd.Parameters.AddWithValue("@ShipCountry", instance.ShipCountry);
            cmd.Parameters.AddWithValue("@CustomerID", instance.CustomerID);
            cmd.Parameters.AddWithValue("@EmployeeID", instance.EmployeeID);
            cmd.Parameters.AddWithValue("@ShipVia", instance.ShipVia);

            //-----------------------------
            int sonuc = 0;
            try
            {
                if (cnn.State == ConnectionState.Closed)
                    cnn.Open();
                sonuc = cmd.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            catch (Exception ey)
            {
                System.Windows.Forms.MessageBox.Show(ey.Message);
            }
            finally
            {
                cnn.Close();
            }
            return sonuc;
        }

        public override int Update(Entity.Orders instance)
        {
            cmd = new SqlCommand("pr_ordersupdate", cnn);
            cmd.CommandType = CommandType.StoredProcedure;
            //---------------
            cmd.Parameters.AddWithValue("@OrderID", instance.id);
            cmd.Parameters.AddWithValue("@ShipName", instance.ShipName);
            cmd.Parameters.AddWithValue("@OrderDate", Convert.ToDateTime(instance.OrderDate));
            cmd.Parameters.AddWithValue("@RequiredDate", Convert.ToDateTime(instance.RequiredDate));
            cmd.Parameters.AddWithValue("@ShippedDate", Convert.ToDateTime(instance.ShippedDate));
            cmd.Parameters.AddWithValue("@Freight", instance.Freight);
            cmd.Parameters.AddWithValue("@ShipAddress", instance.ShipAddress);
            cmd.Parameters.AddWithValue("@ShipRegion", instance.ShipRegion);
            cmd.Parameters.AddWithValue("@ShipPostalCode", instance.ShipPostalCode);
            cmd.Parameters.AddWithValue("@ShipCity", instance.ShipCity);
            cmd.Parameters.AddWithValue("@ShipCountry", instance.ShipCountry);
            cmd.Parameters.AddWithValue("@CustomerID", instance.CustomerID);
            cmd.Parameters.AddWithValue("@EmployeeID", instance.EmployeeID);
            cmd.Parameters.AddWithValue("@ShipVia", instance.ShipVia);

            //-----------------------------
            int sonuc = 0;
            try
            {
                if (cnn.State == ConnectionState.Closed)
                    cnn.Open();
                sonuc = cmd.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            catch (Exception ey)
            {
                System.Windows.Forms.MessageBox.Show(ey.Message);
            }
            finally
            {
                cnn.Close();
            }
            return sonuc;
        }
    
    }
}
