﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AdoNet_DAL_Detayli_Proje.Entity;
using System.Data.SqlClient;
using System.Data;

namespace AdoNet_DAL_Detayli_Proje.DAL
{
    // 8. DataAccess.cs'den geldim ...
    public class ProductDal : DataAccessLayer<Entity.Products> // Entity dosyasının içindeki Products
    {
        // Connected Mimari Çalışalım ...
        SqlConnection cnn = new SqlConnection(Properties.Settings.Default.SqlConString);
        SqlCommand cmd;
        SqlDataReader reader;

        // List -Listeleme : Select Sorgumuz ..
        public override List<Entity.Products> List()
        {
            // I. yol : Normal,Sorgu ile getirme...
            //cmd = new SqlCommand("Select * From Products",cnn);

            // II. yol : stored procedure ile getirme...
            cmd = new SqlCommand("pr_productlist",cnn);
            cmd.CommandType = CommandType.StoredProcedure;

            List<Entity.Products> urunler = new List<Entity.Products>();

            try
            {
                if (cnn.State == ConnectionState.Closed)
                    cnn.Open();
                reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Entity.Products urun = new Entity.Products();
                        urun.id = Convert.ToInt32(reader["ProductID"].ToString()); // Kalıtımdan geldi...
                        //-------------------------------
                        urun.ProductName = reader["ProductName"].ToString();
                        urun.UnitPrice = Convert.ToDecimal(reader["UnitPrice"].ToString());
                        urun.UnitsInStock = Convert.ToInt32(reader["UnitsInStock"].ToString());
                        urun.UnitsOnOrder = Convert.ToInt32(reader["UnitsOnOrder"].ToString());
                        urun.Discontinued = Convert.ToBoolean(reader["Discontinued"].ToString());
                        //------------------------------------
                        urun.CategoryID = Convert.ToInt32(reader["CategoryID"].ToString());
                        urun.SupplierID = Convert.ToInt32(reader["SupplierID"].ToString());

                        urunler.Add(urun);// burda yukarda urunler list tipinde
                    }
                }
            }
            catch (SqlException ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            catch (Exception ey)
            {
                System.Windows.Forms.MessageBox.Show(ey.Message);
            }
            finally
            {
                cnn.Close();
            }
            return urunler;
        }
        // 15. frmEkleden Geldim...
        public override int Save(Entity.Products instance)
        {
            cmd = new SqlCommand("pr_productsave", cnn);
            cmd.CommandType = CommandType.StoredProcedure;
            //---------------
            cmd.Parameters.AddWithValue("@ProductName", instance.ProductName);
            cmd.Parameters.AddWithValue("@UnitPrice", instance.UnitPrice);
            cmd.Parameters.AddWithValue("@UnitsInStock", instance.UnitsInStock);
            cmd.Parameters.AddWithValue("@UnitsOnOrder", instance.UnitsOnOrder);
            cmd.Parameters.AddWithValue("@Discontinued", instance.Discontinued);
            cmd.Parameters.AddWithValue("@CatID", instance.CategoryID);
            cmd.Parameters.AddWithValue("@SupID", instance.SupplierID);

            //-----------------------------
            int sonuc = 0;
            try
            {
                if (cnn.State == ConnectionState.Closed)
                    cnn.Open();
                sonuc = cmd.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            catch (Exception ey)
            {
                System.Windows.Forms.MessageBox.Show(ey.Message);
            }
            finally
            {
                cnn.Close();
            }
            return sonuc;
        }
        public override Entity.Products Load(object instanceId)
        {
            throw new NotImplementedException();
        }


        public override int Update(Entity.Products instance)
        {
            cmd = new SqlCommand("pr_productupdate", cnn);
            cmd.CommandType = CommandType.StoredProcedure;
            //---------------
            cmd.Parameters.AddWithValue("@id", instance.id);
            cmd.Parameters.AddWithValue("@ProductName", instance.ProductName);
            cmd.Parameters.AddWithValue("@UnitPrice", instance.UnitPrice);
            cmd.Parameters.AddWithValue("@UnitsInStock", instance.UnitsInStock);
            cmd.Parameters.AddWithValue("@UnitsOnOrder", instance.UnitsOnOrder);
            cmd.Parameters.AddWithValue("@Discontinued", instance.Discontinued);
            cmd.Parameters.AddWithValue("@CatID", instance.CategoryID);
            cmd.Parameters.AddWithValue("@SupID", instance.SupplierID);

            //-----------------------------
            int sonuc = 0;
            try
            {
                if (cnn.State == ConnectionState.Closed)
                    cnn.Open();
                sonuc = cmd.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            catch (Exception ey)
            {
                System.Windows.Forms.MessageBox.Show(ey.Message);
            }
            finally
            {
                cnn.Close();
            }
            return sonuc;
        }

        public override int Delete(object instanceId)
        {
            cmd = new SqlCommand("pr_productdelete", cnn);
            cmd.CommandType = CommandType.StoredProcedure;
            //---------------
            cmd.Parameters.AddWithValue("@id", instanceId);

            //-----------------------------
            int sonuc = 0;
            try
            {
                if (cnn.State == ConnectionState.Closed)
                    cnn.Open();
                sonuc = cmd.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            catch (Exception ey)
            {
                System.Windows.Forms.MessageBox.Show(ey.Message);
            }
            finally
            {
                cnn.Close();
            }
            return sonuc;
        }
    }
}
