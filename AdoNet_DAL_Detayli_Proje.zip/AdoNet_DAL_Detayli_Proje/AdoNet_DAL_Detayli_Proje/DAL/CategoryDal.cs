﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AdoNet_DAL_Detayli_Proje.Entity;
using System.Data.SqlClient;
using System.Data;

namespace AdoNet_DAL_Detayli_Proje.DAL
{

    public class CategoryDal : DataAccessLayer<Entity.Category>
    {
        SqlConnection cnn = new SqlConnection(Properties.Settings.Default.SqlConString);
        SqlCommand cmd;
        SqlDataReader reader;

        public override List<Category> List()
        {
            cmd = new SqlCommand("pr_categorylist", cnn);
            cmd.CommandType = CommandType.StoredProcedure;

            List<Entity.Category> kategoriler = new List<Entity.Category>();
            try
            {
                if (cnn.State == ConnectionState.Closed)
                    cnn.Open();
                reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Entity.Category cat = new Entity.Category();
                        cat.id = Convert.ToInt32(reader["CategoryID"].ToString()); // Kalıtımdan geldi...
                        //-------------------------------
                        cat.CategoryName = reader["CategoryName"].ToString();
                        cat.Description = reader["Description"].ToString();

                        kategoriler.Add(cat);
                    }
                }
            }
            catch (SqlException ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            catch (Exception ey)
            {
                System.Windows.Forms.MessageBox.Show(ey.Message);
            }
            finally
            {
                cnn.Close();
            }
            return kategoriler;
        }
        public override int Save(Category instance)
        {
            cmd = new SqlCommand("pr_categorysave",cnn);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@CategoryName",instance.CategoryName);
            cmd.Parameters.AddWithValue("@Description", instance.Description);

            int sonuc = 0;
            try
            {
                if (cnn.State == ConnectionState.Closed)
                    cnn.Open();
                sonuc = cmd.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            catch (Exception ey)
            {
                System.Windows.Forms.MessageBox.Show(ey.Message);
            }
            finally
            {
                cnn.Close();
            }
            return sonuc;
        }
        public override int Update(Category instance)
        {
            cmd = new SqlCommand("pr_categoryupdate",cnn);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@id", instance.id);
            //------------------------------
            cmd.Parameters.AddWithValue("@CategoryName", instance.CategoryName);
            cmd.Parameters.AddWithValue("@Description", instance.Description);

            int sonuc = 0;
            try
            {
                if (cnn.State == ConnectionState.Closed)
                    cnn.Open();
                sonuc = cmd.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            catch (Exception ey)
            {
                System.Windows.Forms.MessageBox.Show(ey.Message);
            }
            finally
            {
                cnn.Close();
            }
            return sonuc;
        }

        public override int Delete(object instanceId)
        {
            cmd = new SqlCommand("pr_categorydelete",cnn);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@id",instanceId);

            int sonuc = 0;
            try
            {
                if (cnn.State == ConnectionState.Closed)
                    cnn.Open();
                sonuc = cmd.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            catch (Exception ey)
            {
                System.Windows.Forms.MessageBox.Show(ey.Message);
            }
            finally
            {
                cnn.Close();
            }
            return sonuc;
        }


        public override Category Load(object instanceId)
        {
            throw new NotImplementedException();
        }


    }
}
