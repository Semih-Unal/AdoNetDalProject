﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdoNet_DAL_Detayli_Proje.DAL
{
    // 7. Category.cs'den Geldim ...
    public abstract class DataAccessLayer<T> // Type Generic Type <T> -> mesela Products vb. yazarsanız onun için DML işlemlerini vb. yapar...
    {
        // implementlerimizi yani DML yapılarımızı burada tanımlayalım ...

        //Ekleme / Kaydetme için Abstract metodu tanımladım -> içi boş
        public abstract int Save(T instance);
        //-------------------------------------
        // Update için Abstract metodu tanımladım -> içi boş
        public abstract int Update(T instance);
        //-------------------------------------
        // Silme işlemim -> (Id'ye göre silinecek!)
        public abstract int Delete(object instanceId);
        //-------------------------------------
        // Listeleme / Select abstract metodum -> içi boş
        public abstract List<T> List();
        //---------------------------------------
        // Yükleme işlemim için -> Id'ye göre yüklenecek ...
        public abstract T Load(object instanceId);

        // Şimdi bu abstract classı kullanmak için -> DAL içine -> Productdal.cs classı açıyorum ve ordayım ...


    }
}
