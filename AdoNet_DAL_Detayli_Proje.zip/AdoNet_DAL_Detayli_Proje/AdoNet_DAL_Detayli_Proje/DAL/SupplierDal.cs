﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AdoNet_DAL_Detayli_Proje.Entity;
using System.Data.SqlClient;
using System.Data;

namespace AdoNet_DAL_Detayli_Proje.DAL
{
    public class SupplierDal : DataAccessLayer<Entity.Supplier>
    {

        SqlConnection cnn = new SqlConnection(Properties.Settings.Default.SqlConString);
        SqlCommand cmd;
        SqlDataReader reader;

        public override List<Supplier> List()
        {
            cmd = new SqlCommand("pr_supplierlist",cnn);
            cmd.CommandType = CommandType.StoredProcedure;

            List<Entity.Supplier> tedarikciler = new List<Entity.Supplier>();

            try
            {
                if (cnn.State == ConnectionState.Closed)
                    cnn.Open();
                reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Entity.Supplier tedarikci = new Entity.Supplier();
                        tedarikci.id = Convert.ToInt32(reader["SupplierID"].ToString()); // Kalıtımdan geldi...
                                                                                         //-------------------------------

                        tedarikci.CompanyName = reader["CompanyName"].ToString();
                        tedarikci.ContactName = reader["ContactName"].ToString();
                        tedarikci.ContactTitle = reader["ContactTitle"].ToString();
                        tedarikci.Address = reader["Address"].ToString();
                        tedarikci.City = reader["City"].ToString();
                        tedarikci.Region = reader["Region"].ToString();
                        tedarikci.PostalCode = reader["PostalCode"].ToString();
                        tedarikci.Country = reader["Country"].ToString();
                        tedarikci.Phone = reader["Phone"].ToString();
                        tedarikci.Fax = reader["Fax"].ToString();

                        tedarikciler.Add(tedarikci);
                    }
                }
            }
            catch (SqlException ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            catch (Exception ey)
            {
                System.Windows.Forms.MessageBox.Show(ey.Message);
            }
            finally
            {
                cnn.Close();
            }
            return tedarikciler;
        }
        public override int Save(Supplier instance)
        {
            cmd = new SqlCommand("pr_suppliersave",cnn);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@CompanyName", instance.CompanyName);
            cmd.Parameters.AddWithValue("@ContactName", instance.ContactName);
            cmd.Parameters.AddWithValue("@ContactTitle", instance.ContactTitle);
            cmd.Parameters.AddWithValue("@Address", instance.Address);
            cmd.Parameters.AddWithValue("@City", instance.City);
            cmd.Parameters.AddWithValue("@Region", instance.Region);
            cmd.Parameters.AddWithValue("@PostalCode", instance.PostalCode);
            cmd.Parameters.AddWithValue("@Country", instance.Country);
            cmd.Parameters.AddWithValue("@Phone", instance.Phone);
            cmd.Parameters.AddWithValue("@Fax", instance.Fax);
            //-----------------------------
            int sonuc = 0;
            try
            {
                if (cnn.State == ConnectionState.Closed)
                    cnn.Open();
                sonuc = cmd.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            catch (Exception ey)
            {
                System.Windows.Forms.MessageBox.Show(ey.Message);
            }
            finally
            {
                cnn.Close();
            }
            return sonuc;
        }

        public override int Delete(object instanceId)
        {
            cmd = new SqlCommand("pr_supplierdelete",cnn);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@id", instanceId);

            //-----------------------------
            int sonuc = 0;
            try
            {
                if (cnn.State == ConnectionState.Closed)
                    cnn.Open();
                sonuc = cmd.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            catch (Exception ey)
            {
                System.Windows.Forms.MessageBox.Show(ey.Message);
            }
            finally
            {
                cnn.Close();
            }
            return sonuc;
        }

        public override Supplier Load(object instanceId)
        {
            throw new NotImplementedException();
        }


        public override int Update(Supplier instance)
        {
            cmd = new SqlCommand("pr_supplierupdate",cnn);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@id", instance.id);

            cmd.Parameters.AddWithValue("@CompanyName", instance.CompanyName);
            cmd.Parameters.AddWithValue("@ContactName", instance.ContactName);
            cmd.Parameters.AddWithValue("@ContactTitle", instance.ContactTitle);
            cmd.Parameters.AddWithValue("@Address", instance.Address);
            cmd.Parameters.AddWithValue("@City", instance.City);
            cmd.Parameters.AddWithValue("@Region", instance.Region);
            cmd.Parameters.AddWithValue("@PostalCode", instance.PostalCode);
            cmd.Parameters.AddWithValue("@Country", instance.Country);
            cmd.Parameters.AddWithValue("@Phone", instance.Phone);
            cmd.Parameters.AddWithValue("@Fax", instance.Fax);

            //-----------------------------
            int sonuc = 0;
            try
            {
                if (cnn.State == ConnectionState.Closed)
                    cnn.Open();
                sonuc = cmd.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            catch (Exception ey)
            {
                System.Windows.Forms.MessageBox.Show(ey.Message);
            }
            finally
            {
                cnn.Close();
            }
            return sonuc;
        }
    }
}
